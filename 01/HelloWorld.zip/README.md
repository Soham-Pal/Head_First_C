Hello World
===========

This is a super simple hello world application. It uses a TextView to
display a plain old hello world message via a string resource.
