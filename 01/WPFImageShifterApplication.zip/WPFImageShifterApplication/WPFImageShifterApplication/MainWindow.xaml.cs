﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFImageShifterApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private string imgSource = "";

        public string ImageSource
        {
            get
            {
                return imgSource;
            }
            set
            {
                imgSource = value;
                OnPropertyRaised("ImageSource");
            }
        }
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        private void ButtonGreen_Click(object sender, RoutedEventArgs e)
        {
            ImageSource = "/Resources/Green.png";
        }
        private void ButtonRed_Click(object sender, RoutedEventArgs e)
        {
            ImageSource = "/Resources/Red.png";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyRaised(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }
    }

}