﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web.Http;
using myFirstAPI.Models;

namespace myFirstAPI.Controllers
{
    public class HomeController : ApiController
    {
        static List<Employee> list = new List<Employee>();
        Employee emp;
        Metadata met;
        Error err;
        HttpClient client = new HttpClient();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IHttpActionResult getData()
        {
            GetResponse model = new GetResponse();
            model.metadata = new Metadata();
            model.metadata.Status = "1001";
            model.metadata.Description = "string";
            model.data = list;
            return Ok(model);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="emp"></param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage addData(Employee emp)
        {
            if (emp != null)
            {
                list.Add(emp);
                met = new Metadata();
                met.Status = "success";
                met.Description = "string";
                SuccessResponse model = new SuccessResponse();
                model.metadata = met;
                model.data = emp;
                var response = Request.CreateResponse<SuccessResponse>(HttpStatusCode.Created, model);
                string uri = Url.Link("DefaultApi", new { id = emp.EmployeeID });
                response.Headers.Location = new Uri(uri);
                return response;
            }
            else
            {
                met = new Metadata();
                met.Status = "error";
                met.Description = "string";
                err = new Error();
                err.ID = "1001";
                err.Details = "Bad Request";
                ErrorResponse model = new ErrorResponse();
                model.metadata = met;
                model.error = err;
                var response = Request.CreateResponse<ErrorResponse>(HttpStatusCode.BadRequest, model);
                return response;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="EmployeeID"></param>
        /// <returns></returns>
        [HttpDelete]
        public IHttpActionResult deleteData(int EmployeeID)
        {
            if (EmployeeID.ToString()!=null)
            {
                Employee todelete = new Employee();
                
                int x=0;
                for(int i=0;i<list.Count;i++)
                {
                    if(list[i].EmployeeID==EmployeeID)
                    {
                        todelete = list[i];
                        x=i;
                    }
                }
               
                list.RemoveAt(x);

                SuccessResponse model = new SuccessResponse();
                model.metadata = new Metadata();
                model.metadata.Status = "100001";
                model.metadata.Description = "string";
                model.data = todelete;

                var response = Request.CreateResponse<SuccessResponse>(HttpStatusCode.Found, model);

                string uri = Url.Link("DefaultApi", new { id = todelete.EmployeeID });
                response.Headers.Location = new Uri(uri);
                return Ok(model);
             
            }
            else
            {
                met = new Metadata();
                met.Status = "error";
                met.Description = "string";
                err = new Error();
                err.ID = "1001";
                err.Details = "Bad Request";
               // var response = Request.CreateResponse<Error>(HttpStatusCode.BadRequest, err);
                return Ok("Some Error Occured");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        [HttpPut]
        public IHttpActionResult putData(Employee e)
        {
            if (e.EmployeeID.ToString() != null)
            {
                Employee todelete = new Employee();
                
                int x = 0;
                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i].EmployeeID == e.EmployeeID)
                    {
                        todelete = list[i];
                        x = i;
                    }
                }

                list.RemoveAt(x);
                list.Add(e);
                SuccessResponse model = new SuccessResponse();
                model.metadata = new Metadata();
                model.metadata.Status = "10001";
                model.metadata.Description = "string";
                model.data = todelete;

                var response = Request.CreateResponse<SuccessResponse>(HttpStatusCode.Found, model);

                string uri = Url.Link("DefaultApi", new { id = todelete.EmployeeID });
                response.Headers.Location = new Uri(uri);
                return Ok(model);

            }
            else
            {
                met = new Metadata();
                met.Status = "error";
                met.Description = "string";
                err = new Error();
                err.ID = "1001";
                err.Details = "Bad Request";
                // var response = Request.CreateResponse<Error>(HttpStatusCode.BadRequest, err);
                return Ok(met);
            }
        }
    }
}
