﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace myFirstAPI.Models
{
    public class Metadata
    {
        public string Status { get; set; }
        public string Description { get; set; }
    }
}